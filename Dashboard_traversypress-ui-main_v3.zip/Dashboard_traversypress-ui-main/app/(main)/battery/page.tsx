const battery = () => {
  return ( 
    <div>
      Battery analytics
    </div>
   );
}
 
export default battery;