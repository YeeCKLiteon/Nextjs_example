const  PostPage2 = () => {
    return ( 
        <div>
         Page 2     
        </div>

     );
}
 
export default ;